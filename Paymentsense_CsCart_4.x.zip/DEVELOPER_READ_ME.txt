Disclaimer: PaymentSense provides this code as an example of a working integration module. 
Responsibility for the final implementation, functionality and testing of the module resides with the merchant/merchants website developer.

                                             
THIS DOCUMENT IS FOR DEVELOPERS
-----------------------------------------------------------------------------------------------
----CSCART-VERSION-4.x.x-----------------------------------------------------------------------

STEP ONE
---------

Please ensure you collect the following information from your client prior to integrating:

+ Merchant Gateway ID
+ Merchant Gateway Password
+ PreSharedKey
+ HashMethod Must be set as SHA1 in the Merchants Merchant Management System



STEP TWO
---------

A Full integration Guide for CSCart is located inside the INTEGRATION_DOCUMENT folder. 

Please Read the INTEGRATION_GUIDE.html