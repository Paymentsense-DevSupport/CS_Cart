Disclaimer: PaymentSense provides this code as an example of a working integration module. 
Responsibility for the final implementation, functionality and testing of the module resides with the merchant/merchants website developer.


THIS DOCUMENT IS FOR MERCHANTS
-----------------------------------------------------------------------------------------------
----CSCART-VERSION-4.x.x-----------------------------------------------------------------------

----PLEASE NOTE YOU SHOULD NOT PROVIDE YOUR DEVELOPER OR ANYONE ELSE WITH YOUR MASTER MERCHANT MANAGEMENT SYSTEM LOGIN DETAILS----
----PLEASE CREATE A NEW USER VIA THE USER ADMIN SECTION WITHIN THE MERCHANT MANAGEMENT SYSTEM----

Your Developer will need the follwoing Merchant Management System (MMS) Account information:

1) The Merchant Gateway ID 

 - You can find this in the email FROM: "ecomsupport" with the SUBJECT: "New Gateway Account [ XXXXXXX ]"


2) The Merchant Gateway Password 

 - If you are using a test account, you can find this in the same email as your MerchantID (This was sent to you via email FROM: "ecomsupport" with the SUBJECT: "New Gateway Account [ XXXXXXX ]")
 
 - If you are using a production account your Merchant Gateway Password would need to be set by YOU via the Gateway Account Admin section with the Merchant Management System.


3) The PreSharedsKey

 - This can be found in the Merchant Management System 'Account Settings' 


4) The HashMethod set to SHA1

 - This can be found in the Merchant Management System 'Account Settings' 

-----------------------------------------------------------------------------------------------